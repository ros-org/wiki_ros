Original Authors
----------------

 * [Russell Toris](http://users.wpi.edu/~rctoris/) (rctoris@wpi.edu)

Contributors
------------

 * Jihoon Lee (jihoonlee.in@gmail.com)
 * Lars Kunze (l.kunze@cs.bham.ac.uk)
