2015-09-11 - **0.4.0**
 * Improved ImageMapclient and set to private all variables in ImageMapClient and OccupancyGridClient [(rbonghi)](https://github.com/rbonghi/)
 * Added the possibility to use the NavigationImage instead the NavigationArrow [(haas85)](https://github.com/haas85/)
 * Update Navigator.js [(rbonghi)](https://github.com/rbonghi/)
 * Update OccupancyGridClientNav.js [(rbonghi)](https://github.com/rbonghi/)

2014-08-08 - **0.3.0**
 * Added ImageMapClientNav [(rctoris)](https://github.com/rctoris/)
 * Fixed incorrect shift in OccupancyGridClientNav [(rctoris)](https://github.com/rctoris/)

2013-07-08 - **r2**
 * Shift added to grid client to center on map [(rctoris)](https://github.com/rctoris/)
 * OccupancyGridClientNav now correctly uses the topic parameter [(rctoris)](https://github.com/rctoris/)
 * Navigator now allows click and hold for orientation [(kunzel)](https://github.com/kunzel/)

2013-04-15 - **r1**
 * Initial development of NAV2D [(rctoris)](https://github.com/rctoris/)
