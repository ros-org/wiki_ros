Original Authors
----------------

 * [Russell Toris](http://users.wpi.edu/~rctoris/) (rctoris@wpi.edu)
 * Jihoon Lee (jihoonlee.in@gmail.com)
 * David Gossow (dgossow@willowgarage.com)

Contributors
------------

 * Brandon Alexander (balexander@willowgarage.com)
 * David V. Lu!! (davidvlu@gmail.com)
 * Sarah Osentoski (sarah.osentoski@us.bosch.com)
 * Benjamin Pitzer (ben.pitzer@gmail.com)
 * Xueqiao Xu (xueqiaoxu@gmail.com)
 * Mr.doob - (http://mrdoob.com)
 * AlteredQualia - (http://alteredqualia.com)

