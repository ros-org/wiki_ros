^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package robot_web_tools
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.3 (2014-10-30)
------------------
* changes to new video server dep
* Contributors: Russell Toris

0.0.2 (2014-10-21)
------------------
* updated deps for non-meta package dep
* Contributors: Russell Toris

0.0.1 (2014-08-20)
------------------
* launch files added
* initial READMEs and such
* Contributors: Russell Toris
