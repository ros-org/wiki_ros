^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package cob_undercarriage_ctrl_node
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.6.11 (2016-04-01)
-------------------
* parametrizable odometry tracker in undercarriage_ctrl node
* whitespace fixes
* fix CMakeLists
* ping travis
* [hotfix] compile error
* migrated to OdometryTracker
* migrated to new version of cob_omni_drive_controller
* added cob_undercarriage_ctrl_new by ipa-mig-jg as cob_undercarriage_ctrl_node packge
* Contributors: Florian Weisshardt, Mathias Lüdtke, ipa-fmw, ipa-fxm

0.6.10 (2015-08-31)
-------------------

0.6.9 (2015-08-25)
------------------

0.6.8 (2015-06-22)
------------------

0.6.7 (2015-06-17)
------------------

0.6.6 (2014-12-18 10:49)
------------------------

0.6.5 (2014-12-18 09:08)
------------------------

0.6.4 (2014-12-16 14:10)
------------------------

0.6.3 (2014-12-16 14:00)
------------------------

0.6.2 (2014-12-15)
------------------

0.6.1 (2014-09-22)
------------------

0.6.0 (2014-09-18)
------------------

0.5.4 (2014-08-26 10:26)
------------------------

0.1.0 (2014-08-26 10:23)
------------------------
