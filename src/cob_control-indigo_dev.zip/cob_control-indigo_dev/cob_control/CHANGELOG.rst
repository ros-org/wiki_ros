^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package cob_control
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.6.11 (2016-04-01)
-------------------
* introducing cob_control_msgs
* add cob_undercarriage_ctrl_node to meta-package
* Contributors: Felix Messmer, ipa-fxm

0.6.10 (2015-08-31)
-------------------

0.6.9 (2015-08-25)
------------------
* migrate to package format 2
* sort dependencies
* review dependencies
* add missing run_depends to meta-package
* Contributors: ipa-fxm

0.6.8 (2015-06-17)
------------------
* merge with release candidate
* package renaming: cob_path_broadcaster -> cob_cartesian_controller
* Contributors: ipa-fxm

0.6.7 (2015-06-17)
------------------
* update meta-package
* Contributors: ipa-fxm

0.6.6 (2014-12-18)
------------------

0.6.5 (2014-12-18)
------------------

0.6.4 (2014-12-16)
------------------

0.6.3 (2014-12-16)
------------------

0.6.2 (2014-12-15)
------------------

0.6.1 (2014-09-22)
------------------

0.5.4 (2014-08-26)
------------------
* added meta-package
* Contributors: ipa-fxm
