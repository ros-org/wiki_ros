^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package cob_footprint_observer
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.6.11 (2016-04-01)
-------------------

0.6.10 (2015-08-31)
-------------------

0.6.9 (2015-08-25)
------------------
* boost revision
* do not install headers in executable-only packages
* explicit dependency to boost
* explicit dependency to boost
* remove trailing whitespaces
* migrate to package format 2
* sort dependencies
* review dependencies
* Contributors: ipa-fxm

0.6.8 (2015-06-17)
------------------

0.6.7 (2015-06-17)
------------------
* beautify CMakeLists
* Contributors: ipa-fxm

0.6.6 (2014-12-18)
------------------

0.6.5 (2014-12-18)
------------------

0.6.4 (2014-12-16)
------------------

0.6.3 (2014-12-16)
------------------

0.6.2 (2014-12-15)
------------------

0.6.1 (2014-09-22)
------------------

0.5.3 (2014-03-31)
------------------
* install tags
* Contributors: ipa-fxm

0.5.2 (2014-03-20)
------------------

0.5.1 (2014-03-20)
------------------
* add definitions to get rid of compiler warning
* cob_footprint_observer: introduce epsilon for adjustment and get rid of annoying warning message
* changes for hydro
* cleaned up CMakeLists and added install directives
* further modifications for catkin, now everything is compiling and linking
* futher include and linkpath modifications
* add message dependencies
* compiling but still some linker errors
* Second catkinization push
* First catkinization, still need to update some CMakeLists.txt
* remove param farthest_frame from footprint observer
* change rate of footprint_observer
* changes for fuerte compatibility
* remove unnecessary roslaunch check
* remove unnecessary roslaunch check
* change documentation
* merge launch files and move configs to same folder
* put GetFootprint service into footprint observer
  instead of SetFootprint service in collision velocity filter
  fix namespace problems
* fix namespace problems
* moved safe base movement to driver stack
* Contributors: Alexander Bubeck, Frederik Hegger, abubeck, ipa-fmw, ipa-mig
