^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package cob_model_identifier
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.6.11 (2016-04-01)
-------------------
* working on log output
* Contributors: ipa-fxm

0.6.10 (2015-08-31)
-------------------

0.6.9 (2015-08-25)
------------------
* boost revision
* do not install headers in executable-only packages
* explicit dependency to boost
* more dependency fixes according to review comments
* explicit dependency to boost
* more fixes for migration afer merge
* remove trailing whitespaces
* migrate to package format 2
* cleanup
* sort dependencies
* update with ipa320
* review dependencies
* code styling cob_model_identifier
* beautify and code-review
* Contributors: ipa-fxm

0.6.8 (2015-06-17)
------------------

0.6.7 (2015-06-17)
------------------
* restructure namespaces for parameters of cartesian controllers
* cleanup/replace cob_srvs
* beautify CMakeLists
* remove obsolete files
* remove obsolete config
* new features
* Added README
* cleaned up
* last commit before pull
* cleaning up cob_model_identifier
* neutral file path
* input script for model_identifier
* close file
* fixed console bug
* input_generator as python script
* new features
* merge with fmx-cm
* add tracking_action
* test
* Contributors: Christian Ehrmann, ipa-fxm, ipa-fxm-cm

0.6.6 (2014-12-18)
------------------

0.6.5 (2014-12-18)
------------------

0.6.4 (2014-12-16)
------------------

0.6.3 (2014-12-16)
------------------

0.6.2 (2014-12-15)
------------------
* fix cppcheck errors
* few more changes after testing new structure
* merge with fxm-cm
* cleaning up
* add dependencies
* more topic renaming according to new structure
* temporary commit
* fix install tag
* fix compiler warning
* cleanup, restructure and fix
* moved file
* fixed dependency
* merge with fxm
* fixes + latest changes
* add new package cob_model_identifier
* add new package cob_model_identifier
* Contributors: Florian Weisshardt, ipa-fxm, ipa-fxm-cm

* fix cppcheck errors
* few more changes after testing new structure
* merge with fxm-cm
* cleaning up
* add dependencies
* more topic renaming according to new structure
* temporary commit
* fix install tag
* fix compiler warning
* cleanup, restructure and fix
* moved file
* fixed dependency
* merge with fxm
* fixes + latest changes
* add new package cob_model_identifier
* add new package cob_model_identifier
* Contributors: Florian Weisshardt, ipa-fxm, ipa-fxm-cm

0.6.1 (2014-09-22)
------------------

0.6.0 (2014-09-18)
------------------

0.5.4 (2014-08-26 10:26)
------------------------

0.1.0 (2014-08-26 10:23)
------------------------
