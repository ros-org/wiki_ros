Travis-CI: [![Build Status](https://travis-ci.org/ipa320/cob_control.svg?branch=indigo_dev)](https://travis-ci.org/ipa320/cob_control)

cob_control
===========

The cob_control stack includes packages that are used to do low level control tasks with Care-O-bot hardware over ROS.
