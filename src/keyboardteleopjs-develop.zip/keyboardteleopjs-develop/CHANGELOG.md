2015-02-04 - **0.3.0**
 * Bugfix where any keypress other than wasd would send an empty movement [(dekent)](https://github.com/dekent/)

2013-04-15 - **r2**
 * Switched to Grunt build system [(rctoris)](https://github.com/rctoris/)
 * roslibjs updated to r5 [(rctoris)](https://github.com/rctoris/)
 * Code cleaned for linter [(rctoris)](https://github.com/rctoris/)

2013-03-14 - **r1**
 * Initial development of KEYBOARDTELEOP [(rctoris)](https://github.com/rctoris/)
