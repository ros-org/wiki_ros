module.exports = {
	EventEmitter2: global.EventEmitter2
};