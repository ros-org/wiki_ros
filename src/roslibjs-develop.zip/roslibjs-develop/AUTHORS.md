Original Authors
----------------

 * [Russell Toris](http://users.wpi.edu/~rctoris/) (rctoris@wpi.edu)
 * Jihoon Lee (jihoonlee.in@gmail.com)
 * Brandon Alexander (balexander@willowgarage.com)
 * David Gossow (dgossow@willowgarage.com)
 * Benjamin Pitzer (ben.pitzer@gmail.com)

Contributors
------------

 * Graeme Yeates (yeatesgraeme@gmail.com)
