^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rosapi
^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.7.14 (2016-02-11)
-------------------
* Update proxy.py
  Fixes an issue when call the service "/rosapi/service_type"
* Contributors: Robert Codd-Downey

0.7.13 (2015-08-14)
-------------------
* Fix catkin_lint issues
* Contributors: Matt Vollrath

0.7.12 (2015-04-07)
-------------------

0.7.11 (2015-03-23)
-------------------
* rename rosapi script to rosapi_node to address `#170 <https://github.com/RobotWebTools/rosbridge_suite/issues/170>`_
* Contributors: Jihoon Lee

0.7.10 (2015-02-25)
-------------------
* Make get_topics() and get_topic_type() reference the full list of active topics.
* Contributors: Justin Huang

0.7.9 (2015-02-24)
------------------
* add findding service function as specific service type
* Contributors: dwlee

0.7.8 (2015-01-16)
------------------

0.7.7 (2015-01-06)
------------------

0.7.6 (2014-12-26)
------------------
* 0.7.5
* update changelog
* 0.7.4
* changelog updated
* 0.7.3
* changelog updated
* 0.7.2
* changelog updated
* 0.7.1
* update changelog
* 0.7.0
* changelog updated
* Contributors: Jihoon Lee, Russell Toris

0.7.5 (2014-12-26)
------------------

0.7.4 (2014-12-16)
------------------

0.7.3 (2014-12-15)
------------------

0.7.2 (2014-12-15)
------------------
* 0.7.1
* update changelog
* Contributors: Jihoon Lee

0.7.1 (2014-12-09)
------------------

0.7.0 (2014-12-02)
------------------

0.6.8 (2014-11-05)
------------------

0.6.7 (2014-10-22)
------------------
* updated package manifests
* Contributors: Russell Toris

0.6.6 (2014-10-21)
------------------

0.6.5 (2014-10-14)
------------------
* 0.6.4
* update changelog
* 0.6.3
* update change log
* Contributors: Jihoon Lee

0.6.4 (2014-10-08)
------------------

0.6.3 (2014-10-07)
------------------

0.6.2 (2014-10-06)
------------------

0.6.1 (2014-09-01)
------------------
* make rosapis use absolute namespace
* Contributors: Jihoon Lee

0.6.0 (2014-05-23)
------------------
* Ensure proper locking for Parameter Server access
* Contributors: Lasse Rasinen

0.5.4 (2014-04-17)
------------------
* add rosnode and rosgraph
* Contributors: Jihoon Lee

0.5.3 (2014-03-28)
------------------

0.5.2 (2014-03-14)
------------------

0.5.1 (2013-10-31)
------------------

0.5.0 (2013-07-17)
------------------
* 0.5.0 preparation for hydro release
* Removes trailing commas.
* removing global bin installation in setup.py
* Contributors: Brandon Alexander, Jihoon Lee

0.4.4 (2013-04-08)
------------------

0.4.3 (2013-04-03 08:24)
------------------------

0.4.2 (2013-04-03 08:12)
------------------------
* eclipse projects removed
* Contributors: Russell Toris

0.4.1 (2013-03-07)
------------------
* fixes import issue in rosapi
* Contributors: Russell Toris

0.4.0 (2013-03-05)
------------------
* Fixes ambiguous params class reference.
* Uses only 1 .gitignore to avoid confusion.
* Fixing rosapi's "Cannot include proxy..." errors.
* Adds BSD license header to code files.
  See Issue `#13 <https://github.com/RobotWebTools/rosbridge_suite/issues/13>`_.
* rosbridge_server requires rosapi.
* Adds message and service generation to rosapi.
* Adding setup.py to rosapi.
* Clarifies name of rosapi is rosapi.
* Catkinizes rosapi.
* Collapse directory structure.
* Contributors: Austin Hendrix, Brandon Alexander
